# AGENTS.md — Binance MultiStrategy v0.1

## Intenção do usuário

Implementar e validar primeiro o núcleo multiestratégia v0.1 para Binance Spot/USD-M.
Melhorar em ciclos mensuráveis, buscando lucro líquido razoável e risco controlado.
Só depois experimentar Laya especializado ou Jev para verificar benefício incremental.
Não tornar esses modelos dependências iniciais nem presumir que agregam valor.

Leia `docs/HANDOFF_LOCAL.md` (revisão documental 2, 27/09/2026), `README.md` e
`docs/PROTOCOL.md` antes de implementar. Esta entrega altera documentação, não o código.

## Prioridades

1. Reproduzir testes, obter/auditar dados reais e executar a pesquisa v0.1.
2. Comparar regras sem ML com o filtro numérico já existente; preservar ambos.
3. Corrigir/aperfeiçoar por hipóteses registradas e validação temporal, sem tuning no teste final.
4. Implementar observabilidade, coleta contínua, paper e, depois, demo/reconciliação.
5. Manter treinamento Laya e integração Jev fora desta etapa prioritária.

## Invariantes

- Indicadores, gatilhos, risco, stop e trailing ficam no código. Ausência de Laya/Jev
  não significa remover o classificador/regressor numérico da v0.1.
- Não perseguir 70% sacrificando resultado líquido ou risco. Os gates existentes
  permanecem: não relaxá-los silenciosamente. Não inventar meta mensal de rentabilidade.
- Não chamar APIs pagas de modelos a cada decisão nesta fase.
- Não usar dados futuros, mascarar perdas, aumentar alavancagem para aprovar resultados
  nem executar busca ilimitada até encontrar um backtest favorável.
- Registrar experimentos, inclusive negativos; versionar dados/config/código/modelo.
- Paper diagnóstico não é produção. Nenhum gate autoriza ordens reais automaticamente.
- Preservar pesquisas existentes e instruções locais aplicáveis ao integrar o subprojeto.
- Não confundir o relatório histórico de 52 testes com uma execução atual; reproduzi-los.

## Primeira execução local

```powershell
uv sync --extra dev
uv run pytest -q
uv run multitrader --help
```

Entregar evidências do que foi executado, comparação com a referência, limitações e
próxima hipótese. Continuar a implementação/pesquisa autorizada sem pedir confirmação
para cada ajuste; não habilitar custos externos ou dinheiro real sem autorização.
